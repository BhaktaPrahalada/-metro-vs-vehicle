import React, { useState } from "react";
import { createRoot } from "react-dom/client";

// Rough CO2 emission factors (g per km per person)
const EMISSION_FACTORS: Record<string, number> = {
  bike: 35,      // two-wheeler
  car_petrol: 120,
  car_diesel: 140,
  auto: 100,     // auto-rickshaw
};

const VEHICLE_LABELS: Record<string, string> = {
  bike: "Two-wheeler (bike/scooter)",
  car_petrol: "Car (petrol)",
  car_diesel: "Car (diesel)",
  auto: "Auto-rickshaw",
};

const METRO_FACTOR = 15; // g CO2 per km per person (grid-powered metro, shared load)

const PEAK_TIPS = [
  "Avoid 8:30–10:30 AM and 6:00–8:00 PM on the Blue Line (Nagole–Raidurg) — the busiest stretch.",
  "Ameerpet interchange is the most congested station — if your route allows, change lines at a quieter stop or walk through non-peak gates.",
  "Stand away from the first two doors of each coach — most crowding bunches near entry points.",
  "Carry a smart card/NCMC card to skip the token queue — it saves the most time during rush hour.",
  "If your schedule is flexible, shifting by just 20–30 minutes outside peak windows cuts crowding noticeably.",
];

// Fuel economy (km per litre) and fuel price (₹ per litre), rough Hyderabad averages
const FUEL_ECONOMY: Record<string, number> = {
  bike: 40,
  car_petrol: 14,
  car_diesel: 18,
  auto: 25,
};
const FUEL_PRICE: Record<string, number> = {
  bike: 107,       // petrol
  car_petrol: 107,
  car_diesel: 97,
  auto: 97,        // many autos run on diesel/CNG; using diesel price as approximation
};
const PARKING_COST: Record<string, number> = {
  bike: 10,
  car_petrol: 40,
  car_diesel: 40,
  auto: 0,
};
const METRO_FARE_PER_KM = 2.5; // rough ₹ per km, capped by typical fare slabs

function estimateMetroFare(dist: number) {
  // Hyderabad Metro fare slabs are roughly ₹10–₹60; approximate with per-km rate and a floor/cap
  const raw = dist * METRO_FARE_PER_KM;
  return Math.min(Math.max(raw, 10), 60);
}

const CROWD_LEVELS = [
  { key: "low", label: "Not crowded" },
  { key: "medium", label: "Moderately crowded" },
  { key: "high", label: "Very crowded" },
];

const CROWD_TIPS: Record<string, string[]> = {
  low: [
    "You're likely already riding outside peak windows — stick to this timing if your schedule allows.",
    "Any coach and entry point should be comfortable; no real adjustment needed.",
  ],
  medium: [
    "Try shifting your trip by 15–20 minutes earlier or later — moderate crowding often clears quickly outside the exact peak.",
    "Use entry points away from the main interchange gates (e.g. secondary entries at Ameerpet, Miyapur, or LB Nagar) — they're less congested.",
    "Board from the end coaches rather than the middle ones — foot traffic concentrates near the centre of the platform.",
  ],
  high: [
    "If possible, avoid 8:30–10:30 AM and 6:00–8:00 PM entirely — this is when 'very crowded' routes peak hardest.",
    "Consider an alternate nearby station one stop away if it's less of an interchange hub — Ameerpet, MG Bus Station, and Hitec City tend to be the worst bottlenecks.",
    "Use the first or last coach, and the end-of-platform entry gates — crowding is heaviest near escalators and ticket counters.",
    "If your trip is flexible, splitting it — walking/auto to a quieter adjacent station — can cut wait time significantly.",
  ],
};

function App() {
  const [distance, setDistance] = useState("10");
  const [vehicle, setVehicle] = useState("car_petrol");
  const [showResult, setShowResult] = useState(false);
  const [crowdLevel, setCrowdLevel] = useState("medium");

  const dist = parseFloat(distance) || 0;
  const vehicleEmission = (EMISSION_FACTORS[vehicle] * dist) / 1000; // kg CO2
  const metroEmission = (METRO_FACTOR * dist) / 1000; // kg CO2
  const co2Saved = Math.max(vehicleEmission - metroEmission, 0);
  const percentSaved = vehicleEmission > 0 ? Math.round((co2Saved / vehicleEmission) * 100) : 0;

  // Money saved per trip: vehicle fuel cost + parking vs metro fare
  const fuelCost = (dist / FUEL_ECONOMY[vehicle]) * FUEL_PRICE[vehicle];
  const vehicleTripCost = fuelCost + PARKING_COST[vehicle];
  const metroFare = estimateMetroFare(dist);
  const moneySavedPerTrip = Math.max(vehicleTripCost - metroFare, 0);
  const moneySavedPerWeek = moneySavedPerTrip * 5;

  // Rough traffic reduction framing: 1 fewer vehicle trip on the road
  const trafficNote =
    vehicle === "bike"
      ? "One fewer two-wheeler on the road for this trip."
      : vehicle === "auto"
      ? "One fewer auto-rickshaw trip contributing to road congestion."
      : "One fewer car occupying road space — cars take up far more road area per person than bikes or autos.";

  return (
    <div className="top-clearance bottom-clearance min-h-screen bg-gray-50 flex items-center justify-center px-4">
      <div className="w-full max-w-md">
        <h1 className="text-2xl sm:text-3xl font-bold text-gray-900 mb-1">
          Metro vs. Vehicle
        </h1>
        <p className="text-sm text-gray-500 mb-6 sm:mb-8">
          For your commute in Hyderabad — compare the real impact of taking the metro vs. your own vehicle.
        </p>

        <div className="bg-white rounded-xl shadow-md p-5 sm:p-6 space-y-5">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Trip distance (km)
            </label>
            <input
              type="number"
              min="0"
              step="0.5"
              value={distance}
              onChange={(e) => setDistance(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Your usual vehicle
            </label>
            <select
              value={vehicle}
              onChange={(e) => setVehicle(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none bg-white"
            >
              {Object.entries(VEHICLE_LABELS).map(([key, label]) => (
                <option key={key} value={key}>
                  {label}
                </option>
              ))}
            </select>
          </div>

          <button
            onClick={() => setShowResult(true)}
            className="w-full px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition font-medium"
          >
            Compare
          </button>
        </div>

        {showResult && dist > 0 && (
          <div className="mt-5 sm:mt-6 space-y-4">
            <div className="bg-white rounded-xl shadow-md p-5 sm:p-6">
              <h2 className="text-lg font-semibold text-gray-900 mb-3">
                Pollution saved by taking metro
              </h2>
              <div className="flex items-end gap-2 mb-2">
                <span className="text-3xl sm:text-4xl font-bold text-green-600">
                  {co2Saved.toFixed(2)}
                </span>
                <span className="text-gray-500 pb-1">kg CO₂ per trip</span>
              </div>
              <p className="text-sm text-gray-600">
                That's about {percentSaved}% less emissions than driving your {VEHICLE_LABELS[vehicle].toLowerCase()} for this {dist} km trip.
                Make this trip 5x a week and you'd save roughly{" "}
                <span className="font-medium">{(co2Saved * 5).toFixed(1)} kg CO₂</span> weekly.
              </p>
            </div>

            <div className="bg-white rounded-xl shadow-md p-5 sm:p-6">
              <h2 className="text-lg font-semibold text-gray-900 mb-4">
                Cost comparison: metro vs. driving
              </h2>
              <div className="space-y-4">
                {[
                  {
                    label: VEHICLE_LABELS[vehicle],
                    value: vehicleTripCost,
                    color: "bg-red-400",
                    detail:
                      PARKING_COST[vehicle] > 0
                        ? `Fuel ₹${fuelCost.toFixed(0)} + Parking ₹${PARKING_COST[vehicle]} = ₹${vehicleTripCost.toFixed(0)}`
                        : `Fuel ₹${fuelCost.toFixed(0)} = ₹${vehicleTripCost.toFixed(0)}`,
                  },
                  {
                    label: "Metro",
                    value: metroFare,
                    color: "bg-blue-500",
                    detail: `Fare ₹${metroFare.toFixed(0)} for ${dist} km`,
                  },
                ].map((row) => {
                  const maxVal = Math.max(vehicleTripCost, metroFare) || 1;
                  const widthPct = Math.max((row.value / maxVal) * 100, 4);
                  return (
                    <div key={row.label}>
                      <div className="flex justify-between text-xs text-gray-600 mb-1">
                        <span>{row.label}</span>
                        <span className="font-medium">₹{row.value.toFixed(0)}</span>
                      </div>
                      <div className="w-full bg-gray-100 rounded-full h-5 group relative">
                        <div
                          className={`${row.color} h-5 rounded-full transition-all cursor-default`}
                          style={{ width: `${widthPct}%` }}
                          role="img"
                          aria-label={row.detail}
                        />
                        <div
                          className="pointer-events-none opacity-0 group-hover:opacity-100 transition-opacity absolute -top-9 left-0 bg-gray-900 text-white text-xs rounded-md px-2 py-1 whitespace-nowrap shadow-lg z-10"
                        >
                          {row.detail}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
              <p className="text-xs text-gray-400 mt-3">
                Per-trip cost for a {dist} km ride. Hover a bar for the exact breakdown.
              </p>
            </div>

            <div className="bg-white rounded-xl shadow-md p-5 sm:p-6">
              <h2 className="text-lg font-semibold text-gray-900 mb-3">
                Money saved by taking metro
              </h2>
              <div className="flex items-end gap-2 mb-2">
                <span className="text-3xl sm:text-4xl font-bold text-green-600">
                  ₹{moneySavedPerTrip.toFixed(0)}
                </span>
                <span className="text-gray-500 pb-1">saved per trip</span>
              </div>
              <p className="text-sm text-gray-600">
                Your {VEHICLE_LABELS[vehicle].toLowerCase()} costs roughly ₹{vehicleTripCost.toFixed(0)} per trip
                (₹{fuelCost.toFixed(0)} fuel{PARKING_COST[vehicle] > 0 ? ` + ₹${PARKING_COST[vehicle]} parking` : ""}),
                versus an estimated ₹{metroFare.toFixed(0)} metro fare for {dist} km.
              </p>
              <p className="text-sm text-gray-600 mt-2">
                Over 5 trips a week, that's about{" "}
                <span className="font-medium">₹{moneySavedPerWeek.toFixed(0)}</span> saved weekly.
              </p>

              <div className="mt-5 pt-4 border-t border-gray-100">
                <p className="text-xs font-medium text-gray-500 uppercase tracking-wide mb-3">
                  Before vs. after
                </p>
                <div className="flex items-end justify-center gap-6 sm:gap-10">
                  {(() => {
                    const maxVal = Math.max(vehicleTripCost, metroFare) || 1;
                    const beforeHeight = Math.max((vehicleTripCost / maxVal) * 100, 8);
                    const afterHeight = Math.max((metroFare / maxVal) * 100, 8);
                    return (
                      <>
                        <div className="flex flex-col items-center">
                          <div className="h-32 flex items-end">
                            <div
                              className="w-14 sm:w-16 bg-red-400 rounded-t-md flex items-start justify-center pt-1"
                              style={{ height: `${beforeHeight}%` }}
                            >
                              <span className="text-white text-xs font-semibold">
                                ₹{vehicleTripCost.toFixed(0)}
                              </span>
                            </div>
                          </div>
                          <span className="text-xs text-gray-500 mt-2">Before (driving)</span>
                        </div>

                        <div className="flex flex-col items-center text-green-600 pb-6">
                          <span className="text-xl">→</span>
                          <span className="text-xs font-medium">
                            −₹{moneySavedPerTrip.toFixed(0)}
                          </span>
                        </div>

                        <div className="flex flex-col items-center">
                          <div className="h-32 flex items-end">
                            <div
                              className="w-14 sm:w-16 bg-blue-500 rounded-t-md flex items-start justify-center pt-1"
                              style={{ height: `${afterHeight}%` }}
                            >
                              <span className="text-white text-xs font-semibold">
                                ₹{metroFare.toFixed(0)}
                              </span>
                            </div>
                          </div>
                          <span className="text-xs text-gray-500 mt-2">After (metro)</span>
                        </div>
                      </>
                    );
                  })()}
                </div>
              </div>

              <p className="text-xs text-gray-400 mt-4 pt-3 border-t border-gray-100">
                Assumptions: fuel prices ~₹107/L (petrol), ~₹97/L (diesel); average fuel economy of{" "}
                {FUEL_ECONOMY[vehicle]} km/L for your vehicle type; parking ₹{PARKING_COST[vehicle]} per trip where applicable;
                metro fare estimated at ~₹2.5/km (capped between ₹10–₹60). Actual costs vary by route, traffic, and station.
              </p>
            </div>

            <div className="bg-white rounded-xl shadow-md p-5 sm:p-6">
              <h2 className="text-lg font-semibold text-gray-900 mb-2">
                Traffic impact
              </h2>
              <p className="text-sm text-gray-600">{trafficNote}</p>
              <p className="text-sm text-gray-600 mt-2">
                Hyderabad's road network is already stretched at peak hours — every trip shifted to metro is one less vehicle
                queued at signals on corridors like Ameerpet, Punjagutta, or Mehdipatnam.
              </p>
            </div>

            <div className="bg-white rounded-xl shadow-md p-5 sm:p-6">
              <h2 className="text-lg font-semibold text-gray-900 mb-2">
                Road safety impact
              </h2>
              <p className="text-sm text-gray-600">
                Fewer personal vehicles on the road means less lane-weaving, tailgating, and signal-jumping — the behaviors
                most linked to accidents on Hyderabad's congested corridors. Lighter traffic also gives police clearer
                visibility and faster access to respond to incidents, instead of being boxed in by gridlock. At scale,
                even a modest shift to metro eases the pressure points — like Ameerpet and Mehdipatnam — where congestion
                and accident risk are highest.
              </p>
            </div>

            <div className="bg-white rounded-xl shadow-md p-5 sm:p-6">
              <h2 className="text-lg font-semibold text-gray-900 mb-3">
                How crowded is your usual metro route?
              </h2>
              <div className="flex flex-col sm:flex-row gap-2 mb-4">
                {CROWD_LEVELS.map((level) => (
                  <button
                    key={level.key}
                    onClick={() => setCrowdLevel(level.key)}
                    className={`flex-1 px-3 py-2 rounded-lg text-sm font-medium border transition ${
                      crowdLevel === level.key
                        ? "bg-blue-600 text-white border-blue-600"
                        : "bg-white text-gray-700 border-gray-300 hover:bg-gray-50"
                    }`}
                  >
                    {level.label}
                  </button>
                ))}
              </div>
              <ul className="space-y-2">
                {CROWD_TIPS[crowdLevel].map((tip, i) => (
                  <li key={i} className="text-sm text-gray-600 flex gap-2">
                    <span className="text-blue-600 font-bold">•</span>
                    <span>{tip}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="bg-white rounded-xl shadow-md p-5 sm:p-6">
              <h2 className="text-lg font-semibold text-gray-900 mb-3">
                General tips to avoid peak-hour crowding
              </h2>
              <ul className="space-y-2">
                {PEAK_TIPS.map((tip, i) => (
                  <li key={i} className="text-sm text-gray-600 flex gap-2">
                    <span className="text-blue-600 font-bold">•</span>
                    <span>{tip}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

createRoot(document.getElementById("root")!).render(<App />);
