# Requirements: Metro vs. Vehicle

## Overview
Metro vs. Vehicle is a commute comparison tool for Hyderabad residents that quantifies the environmental, financial, and traffic impact of taking the metro instead of driving a personal vehicle. It helps commuters make informed transport choices by showing real-world savings in CO₂ emissions, trip cost, and weekly budget impact.

## Functional Requirements

### Input & Trip Setup

| ID | Requirement |
|----|-------------|
| REQ-001 | WHEN the user opens the app THE SYSTEM SHALL display an input form with fields for trip distance (km) and vehicle type |
| REQ-002 | WHEN the user enters a trip distance THE SYSTEM SHALL accept numeric input between 0 and any positive number with 0.5 km increments |
| REQ-003 | WHEN the user selects a vehicle type THE SYSTEM SHALL provide four options: two-wheeler (bike/scooter), car (petrol), car (diesel), and auto-rickshaw |
| REQ-004 | WHEN the user clicks "Compare" THE SYSTEM SHALL validate that distance is greater than 0 and display results |

### Emissions Comparison

| ID | Requirement |
|----|-------------|
| REQ-005 | WHEN results are displayed THE SYSTEM SHALL calculate and show CO₂ emissions saved per trip (in kg) by taking metro instead of the selected vehicle |
| REQ-006 | WHEN displaying CO₂ savings THE SYSTEM SHALL show the percentage reduction relative to vehicle emissions |
| REQ-007 | WHEN displaying CO₂ savings THE SYSTEM SHALL extrapolate to a weekly figure (assuming 5 trips per week) |
| REQ-008 | WHEN calculating emissions THE SYSTEM SHALL use these factors: bike 35 g/km, car petrol 120 g/km, car diesel 140 g/km, auto 100 g/km, metro 15 g/km per person |

### Cost Comparison

| ID | Requirement |
|----|-------------|
| REQ-009 | WHEN results are displayed THE SYSTEM SHALL calculate vehicle trip cost as fuel cost plus parking cost |
| REQ-010 | WHEN calculating fuel cost THE SYSTEM SHALL divide trip distance by vehicle fuel economy and multiply by fuel price per litre |
| REQ-011 | WHEN calculating metro fare THE SYSTEM SHALL use a rate of approximately ₹2.5 per km, capped between ₹10 minimum and ₹60 maximum |
| REQ-012 | WHEN displaying cost comparison THE SYSTEM SHALL show per-trip cost for both vehicle and metro with a horizontal bar chart visualization |
| REQ-013 | WHEN the user hovers over a cost bar THE SYSTEM SHALL display a tooltip with the detailed cost breakdown (fuel, parking, fare) |
| REQ-014 | WHEN displaying cost comparison THE SYSTEM SHALL calculate and show money saved per trip in bold green text |
| REQ-015 | WHEN displaying cost comparison THE SYSTEM SHALL extrapolate to a weekly savings figure (assuming 5 trips per week) |
| REQ-016 | WHEN displaying cost comparison THE SYSTEM SHALL show a before-and-after bar chart comparing vehicle cost vs. metro fare visually |

### Impact Messaging

| ID | Requirement |
|----|-------------|
| REQ-017 | WHEN results are displayed THE SYSTEM SHALL show contextual traffic impact messaging that varies by vehicle type (two-wheeler, car, auto) |
| REQ-018 | WHEN results are displayed THE SYSTEM SHALL include a section explaining how reduced vehicles ease congestion at major Hyderabad chokepoints (Ameerpet, Mehdipatnam, Punjagutta) |
| REQ-019 | WHEN results are displayed THE SYSTEM SHALL include a section explaining road safety benefits of fewer personal vehicles |

### Crowding & Tips

| ID | Requirement |
|----|-------------|
| REQ-020 | WHEN results are displayed THE SYSTEM SHALL display a crowding level selector with three options: Not crowded, Moderately crowded, Very crowded |
| REQ-021 | WHEN the user selects a crowding level THE SYSTEM SHALL display contextual tips for that level (e.g., which entry points and coaches to use, timing strategies) |
| REQ-022 | WHEN results are displayed THE SYSTEM SHALL display a fixed list of general peak-hour avoidance tips covering timing, alternate stations, and card usage |

### Assumptions & Transparency

| ID | Requirement |
|----|-------------|
| REQ-023 | WHEN displaying results THE SYSTEM SHALL show a footnote listing all assumptions (fuel prices, fuel economy, parking costs, metro fare estimation, and variability disclaimer) |

## Non-Functional Requirements

| ID | Requirement |
|----|-------------|
| NFR-001 | THE SYSTEM SHALL be fully responsive and usable on mobile (small screens), tablet (medium screens), and desktop (large screens) |
| NFR-002 | THE SYSTEM SHALL calculate and update results in real time as the user modifies distance or vehicle type (no required button click after initial comparison) |
| NFR-003 | THE SYSTEM SHALL display all numeric currency values in Indian Rupees (₹) with zero decimal places for simple figures (e.g., ₹50) or one decimal place for precise breakdowns (e.g., ₹50.5) |
| NFR-004 | THE SYSTEM SHALL display all CO₂ values with two decimal places (e.g., 1.23 kg) |
| NFR-005 | THE SYSTEM SHALL use color coding: green for savings/positive impact, red for vehicle cost, blue for metro/comparison baseline |
| NFR-006 | THE SYSTEM SHALL provide clear visual hierarchy with h1 for app title, h2 for section headings, and consistent spacing |
| NFR-007 | THE SYSTEM SHALL not require user login, persistent storage, or backend API calls — all calculations run client-side |
| NFR-008 | THE SYSTEM SHALL load and render within 2 seconds on a 4G connection |
| NFR-009 | THE SYSTEM SHALL have an empty state where no results show until the user clicks "Compare" with a valid distance |
| NFR-010 | THE SYSTEM SHALL disable or hide the "Compare" button result area until distance > 0 to prevent invalid comparisons |

## Design Notes

**Layout & Structure:**
- Single-column responsive layout, centered card-based design
- Header section with app title and brief tagline at the top
- Input form in a white card (distance field, vehicle dropdown, Compare button)
- Results displayed below form in a series of stacked cards (one per section: emissions, cost, traffic, crowding, tips)
- All cards have consistent rounded corners (11px or similar), shadow, and padding (20–24px)

**Color Scheme:**
- Background: light gray (bg-gray-50)
- Cards: white with subtle shadow
- Primary action button: blue (hover darker blue)
- Savings/positive messaging: green (#22c55e or similar)
- Vehicle cost: red (#f87171 or similar)
- Metro baseline: blue (#3b82f6 or similar)
- Text: dark gray for body, medium gray for secondary labels
- Input focus ring: blue accent

**Typography:**
- App title: 28–32px, bold, dark gray
- Section headings (h2): 18–20px, bold, dark gray
- Body text: 14px, medium gray
- Small text/footnotes: 12px, light gray
- Labels: 14px, medium weight, dark gray

**Responsive Behavior:**
- Mobile (< 640px): full-width input fields, single-column cards, smaller title font (28px), reduced padding
- Tablet (640px–1024px): maintained width with max-width 28rem, adjusted spacing
- Desktop (> 1024px): same max-width, centered on screen with padding on sides
- Bar charts: scale down font and bar width on mobile, grow on larger screens

**Empty/Loading/Error States:**
- Empty state: form visible, no results cards shown until Compare is clicked
- Invalid input (distance ≤ 0): Compare button remains clickable but result section does not render
- Loading state: not applicable (calculations are instant)
- Error state: not applicable (calculations are deterministic, no external data)

**Interactive Elements:**
- Input field: standard number input with keyboard support
- Dropdown: native select element with vehicle options
- Compare button: full-width, blue background, white text, hover effect
- Crowding buttons: toggle-style buttons, active state is blue with white text, inactive is white with gray text
- Hover tooltips on cost bars: appear on hover with dark background and white text, positioned above the bar
- Tooltips disappear on mouse out

**Accessibility:**
- All form inputs have associated `<label>` elements
- Hover tooltips have `role="img"` with `aria-label` for screen readers
- Color is never the sole indicator (e.g., bars are also labeled with text)
- Focus ring visible on all interactive elements
- Button text is descriptive ("Compare", not generic "Submit")