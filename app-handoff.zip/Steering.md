# Steering: Metro vs. Vehicle

## Goal
Build a working web app that helps Hyderabad commuters compare the cost, emissions, and convenience of taking the metro versus driving their own vehicle.

## Context
This was prototyped in PartyRock. The `src/` folder contains a React/Tailwind reference implementation — use it to understand the intended behavior, UI layout, and calculations, NOT as production code to copy. You're handing off a product idea with a working prototype, not a codebase.

## Instructions

1. **Read Requirements.md first.** It has the full product spec in EARS syntax — everything the user wants the app to do.
2. **Skim the reference code** to understand:
   - How distance and vehicle type drive all calculations
   - The three main result cards: emissions savings, cost breakdown, and tips
   - The crowding-level toggle and contextual tips UI
   - Which data (emission factors, fuel costs, metro fares) are hard-coded vs. user inputs
3. **The prototype has sandbox constraints** (no real database, all calculations client-side, no forms saved). Your real implementation should be production-ready.

## Guidance

- **No tech stack specified?** Start by asking: (a) Do you prefer a simple single-page app or a full-stack solution? (b) Do you want hosting recommendations (Vercel, Netlify, AWS)? (c) Any preference between React, Vue, or vanilla JS? Offer a sensible default (React + Vercel) with 1–2 sentences explaining why, then let them choose.
- **No target users, scale, or deployment mentioned.** Ask: (a) Who is your primary user (students, office workers, general commuters)? (b) Do you expect 10s, 100s, or 1000s of users? (c) Do you ever want to track user behavior or gather feedback? (d) Will you ever add features like saved routes, commute history, or carpooling matching?
- **Keep it simple first.** Get a working prototype in front of the user in 1–2 days, not a perfectly architected backend. Responsive, fast, accurate math, and easy to understand — that's the MVP.
- **When in doubt, ask.** The user likely does NOT have a technical background. Explain choices in plain language: "I'd use React because it's fast to build with and easy to add interactivity later. Vercel because it deploys with one click and scales automatically."
- **Reference the code to understand intent, not to copy.** The emission factors, fuel costs, metro fares, and tip text are all context-specific to Hyderabad — preserve those, but rebuild the component structure for production.